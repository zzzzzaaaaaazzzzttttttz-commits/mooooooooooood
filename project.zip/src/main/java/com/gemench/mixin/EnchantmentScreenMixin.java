package com.gemench.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import com.gemench.client.GemTextures;

import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.client.gui.screens.inventory.EnchantmentScreen;
import net.minecraft.client.renderer.RenderPipelines;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.inventory.EnchantmentMenu;

/**
 * Enchanting table screen: no "Enchant" title, and the 3D book is replaced by a pixel-art picture
 * (diamond on an anvil, hit by a hammer). Also covers subclasses such as the Apothic Enchanting screen.
 */
@Mixin(value = EnchantmentScreen.class, remap = false)
public abstract class EnchantmentScreenMixin extends AbstractContainerScreen<EnchantmentMenu> {
    protected EnchantmentScreenMixin(EnchantmentMenu menu, Inventory inventory, Component title) {
        super(menu, inventory, title);
    }

    /** Moves the title label far outside the panel, so it is not visible. */
    @Inject(method = "init", at = @At("TAIL"), remap = false)
    private void gemench$hideTitle(CallbackInfo ci) {
        this.titleLabelY = -1000;
    }

    /**
     * Cancels the 3D book and draws the picture in the free top-left area (x 10..54, y 12..42).
     * The three option buttons start at x = 60, so they stay uncovered.
     */
    @Inject(method = "extractBook", at = @At("HEAD"), cancellable = true, remap = false)
    private void gemench$replaceBook(GuiGraphicsExtractor graphics, int a, int b, CallbackInfo ci) {
        graphics.blit(RenderPipelines.GUI_TEXTURED, GemTextures.ENCHANT_PICTURE, this.leftPos + 10, this.topPos + 12,
                0.0F, 0.0F, 44, 30, 44, 30);
        ci.cancel();
    }
}
