package com.gemench;

import com.gemench.client.GemClient;
import com.gemench.client.TooltipHandler;

import net.minecraft.core.component.DataComponents;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.Items;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.ModContainer;
import net.neoforged.fml.common.Mod;
import net.neoforged.neoforge.common.NeoForge;
import net.neoforged.neoforge.event.ModifyDefaultComponentsEvent;

/** Gem Enchantments: visual and tooltip changes only, so the whole mod is client side. */
@Mod(value = GemEnchantments.MOD_ID, dist = Dist.CLIENT)
public class GemEnchantments {
    public static final String MOD_ID = "gemench";

    public GemEnchantments(IEventBus modBus, ModContainer container) {
        modBus.addListener(GemEnchantments::onModifyDefaultComponents);
        modBus.addListener(GemClient::onRegisterItemProperties);
        modBus.addListener(GemClient::onRegisterRenderers);
        NeoForge.EVENT_BUS.addListener(TooltipHandler::onItemTooltip);
        NeoForge.EVENT_BUS.addListener(TooltipHandler::onGatherTooltipComponents);
    }

    private static void onModifyDefaultComponents(ModifyDefaultComponentsEvent event) {
        // The enchanting table is shown as "Table Ghoul" everywhere.
        event.modify(Items.ENCHANTING_TABLE,
                builder -> builder.set(DataComponents.ITEM_NAME, Component.literal("Table Ghoul")));
    }
}
