package com.gemench.client;

import com.gemench.GemEnchantments;

import net.minecraft.resources.Identifier;

/** Texture locations used by the mixin (kept outside the mixin class on purpose). */
public final class GemTextures {
    public static final Identifier ENCHANT_PICTURE =
            Identifier.fromNamespaceAndPath(GemEnchantments.MOD_ID, "textures/gui/enchant_picture.png");

    private GemTextures() {}
}
