package com.gemench.client;

import com.gemench.Gem;
import com.gemench.Gems;
import com.mojang.serialization.MapCodec;

import it.unimi.dsi.fastutil.objects.Object2IntMap;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.renderer.item.properties.numeric.RangeSelectItemModelProperty;
import net.minecraft.core.Holder;
import net.minecraft.core.component.DataComponents;
import net.minecraft.world.entity.ItemOwner;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.enchantment.Enchantment;
import net.minecraft.world.item.enchantment.ItemEnchantments;

/**
 * Numeric item model property: 0 = no known gem (generic crystal), otherwise gemIndex + 1.
 * Item model definitions use whole numbers as thresholds, so no 0..1 scaling is needed here.
 */
public record GemIndexProperty() implements RangeSelectItemModelProperty {
    public static final MapCodec<GemIndexProperty> MAP_CODEC = MapCodec.unit(new GemIndexProperty());

    @Override
    public float get(ItemStack stack, ClientLevel level, ItemOwner owner, int seed) {
        ItemEnchantments stored = stack.get(DataComponents.STORED_ENCHANTMENTS);
        if (stored == null || stored.isEmpty()) {
            return 0.0F;
        }
        for (Object2IntMap.Entry<Holder<Enchantment>> entry : stored.entrySet()) {
            Gem gem = Gems.find(entry.getKey());
            if (gem != null) {
                return gem.index() + 1;
            }
        }
        return 0.0F;
    }

    @Override
    public MapCodec<GemIndexProperty> type() {
        return MAP_CODEC;
    }
}
