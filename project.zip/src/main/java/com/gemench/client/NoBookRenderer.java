package com.gemench.client;

import com.mojang.blaze3d.vertex.PoseStack;

import net.minecraft.client.renderer.SubmitNodeCollector;
import net.minecraft.client.renderer.blockentity.BlockEntityRenderer;
import net.minecraft.client.renderer.blockentity.BlockEntityRendererProvider;
import net.minecraft.client.renderer.blockentity.state.BlockEntityRenderState;
import net.minecraft.client.renderer.state.level.CameraRenderState;
import net.minecraft.world.level.block.entity.EnchantingTableBlockEntity;

/** Draws nothing: removes the floating book above the enchanting table (the ghoul has no book). */
public class NoBookRenderer implements BlockEntityRenderer<EnchantingTableBlockEntity, NoBookRenderer.State> {
    public static final class State extends BlockEntityRenderState {
    }

    public NoBookRenderer(BlockEntityRendererProvider.Context context) {
    }

    @Override
    public State createRenderState() {
        return new State();
    }

    @Override
    public void submit(State state, PoseStack poseStack, SubmitNodeCollector collector, CameraRenderState camera) {
        // intentionally empty
    }
}
