package com.gemench.client;

import com.gemench.GemEnchantments;

import net.minecraft.resources.Identifier;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.neoforged.neoforge.client.event.EntityRenderersEvent;
import net.neoforged.neoforge.client.event.RegisterRangeSelectItemModelPropertyEvent;

/** Client registrations (mod bus). */
public final class GemClient {
    private GemClient() {}

    /** Registers the "gemench:gem_index" property used by the enchanted book model definition. */
    public static void onRegisterItemProperties(RegisterRangeSelectItemModelPropertyEvent event) {
        event.register(Identifier.fromNamespaceAndPath(GemEnchantments.MOD_ID, "gem_index"), GemIndexProperty.MAP_CODEC);
    }

    /** Replaces the enchanting table renderer so the floating vanilla book is not drawn above the ghoul. */
    public static void onRegisterRenderers(EntityRenderersEvent.RegisterRenderers event) {
        event.registerBlockEntityRenderer(BlockEntityType.ENCHANTING_TABLE, NoBookRenderer::new);
    }
}
