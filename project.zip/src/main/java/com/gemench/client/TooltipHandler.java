package com.gemench.client;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.TreeMap;

import com.gemench.Gem;
import com.gemench.Gems;
import com.mojang.datafixers.util.Either;

import it.unimi.dsi.fastutil.objects.Object2IntMap;
import net.minecraft.ChatFormatting;
import net.minecraft.client.Minecraft;
import net.minecraft.core.Holder;
import net.minecraft.core.component.DataComponents;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.FormattedText;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.network.chat.Style;
import net.minecraft.network.chat.TextColor;
import net.minecraft.network.chat.contents.TranslatableContents;
import net.minecraft.world.inventory.tooltip.TooltipComponent;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.enchantment.Enchantment;
import net.minecraft.world.item.enchantment.ItemEnchantments;
import net.neoforged.neoforge.client.event.RenderTooltipEvent;
import net.neoforged.neoforge.event.entity.player.ItemTooltipEvent;

/**
 * Shift-for-details tooltips for gems: enchanted books, enchanted tools/armor, the four vanilla gem items
 * and the enchanting table hover hint.
 */
public final class TooltipHandler {
    private static final String HINT_TEXT = "Hold Shift for details";
    private static final String CLUE_KEY = "container.enchant.clue";

    private TooltipHandler() {}

    private record Found(Gem gem, int level, Holder<Enchantment> holder) {}

    // ------------------------------------------------------------------ item tooltips

    public static void onItemTooltip(ItemTooltipEvent event) {
        ItemStack stack = event.getItemStack();
        List<Component> tip = event.getToolTip();
        if (tip.isEmpty()) {
            return;
        }
        boolean shift = Minecraft.getInstance().hasShiftDown();

        if (stack.is(Items.ENCHANTED_BOOK)) {
            handleBook(stack, tip, shift);
            return;
        }
        Gem gemItem = vanillaGemItem(stack);
        if (gemItem != null) {
            tip.add(1, shift ? description(gemItem, false) : hint());
            return;
        }
        handleEnchantedItem(stack, tip, shift);
    }

    /** Diamond, emerald, lapis lazuli and amethyst shard stand for an enchantment's gem. */
    private static Gem vanillaGemItem(ItemStack stack) {
        if (stack.is(Items.DIAMOND)) {
            return Gems.byEnchantId("minecraft:protection");
        }
        if (stack.is(Items.EMERALD)) {
            return Gems.byEnchantId("minecraft:mending");
        }
        if (stack.is(Items.LAPIS_LAZULI)) {
            return Gems.byEnchantId("minecraft:knockback");
        }
        if (stack.is(Items.AMETHYST_SHARD)) {
            return Gems.byEnchantId("minecraft:soul_speed");
        }
        return null;
    }

    private static void handleBook(ItemStack stack, List<Component> tip, boolean shift) {
        List<Found> known = knownGems(stack.get(DataComponents.STORED_ENCHANTMENTS));
        if (known.isEmpty()) {
            return; // unknown / modded enchantments keep their normal tooltip
        }
        // Remove exactly the vanilla enchantment lines of the gems we know (this also removes "Curse of ...").
        Set<Integer> used = new HashSet<>();
        for (Found f : longestNameFirst(known)) {
            int i = indexOfLine(tip, f, used);
            if (i >= 1) {
                used.add(i);
            }
        }
        List<Integer> remove = new ArrayList<>(used);
        remove.sort(Comparator.reverseOrder());
        for (int i : remove) {
            tip.remove(i);
        }
        // Title = first gem (colored name + level).
        tip.set(0, nameLine(known.get(0)));

        List<Component> insert = new ArrayList<>();
        if (shift) {
            insert.add(description(known.get(0).gem(), false));
            for (int k = 1; k < known.size(); k++) {
                insert.add(nameLine(known.get(k)));
                insert.add(description(known.get(k).gem(), false));
            }
        } else {
            for (int k = 1; k < known.size(); k++) {
                insert.add(nameLine(known.get(k)));
            }
            insert.add(hint());
        }
        tip.addAll(1, insert);
    }

    private static void handleEnchantedItem(ItemStack stack, List<Component> tip, boolean shift) {
        List<Found> known = knownGems(stack.get(DataComponents.ENCHANTMENTS));
        if (known.isEmpty()) {
            return;
        }
        TreeMap<Integer, Gem> lines = new TreeMap<>();
        Set<Integer> used = new HashSet<>();
        for (Found f : longestNameFirst(known)) {
            int i = indexOfLine(tip, f, used);
            if (i >= 1) {
                used.add(i);
                lines.put(i, f.gem());
            }
        }
        if (lines.isEmpty()) {
            return;
        }
        if (shift) {
            // from the bottom up so earlier indexes stay valid
            for (int idx : lines.descendingKeySet()) {
                tip.add(idx + 1, description(lines.get(idx), true));
            }
        } else {
            tip.add(lines.lastKey() + 1, hint());
        }
    }

    // ------------------------------------------------------------------ enchanting table hover hint

    public static void onGatherTooltipComponents(RenderTooltipEvent.GatherComponents event) {
        List<Either<FormattedText, TooltipComponent>> elements = event.getTooltipElements();
        for (int i = 0; i < elements.size(); i++) {
            Optional<FormattedText> left = elements.get(i).left();
            if (left.isEmpty() || !(left.get() instanceof Component component)) {
                continue;
            }
            if (!(component.getContents() instanceof TranslatableContents contents) || !CLUE_KEY.equals(contents.getKey())) {
                continue;
            }
            Object[] args = contents.getArgs();
            if (args.length == 0) {
                return;
            }
            String shown = args[0] instanceof Component c ? c.getString() : String.valueOf(args[0]);
            Gem gem = Gems.matchDisplayName(shown);
            if (gem == null) {
                return;
            }
            boolean shift = Minecraft.getInstance().hasShiftDown();
            elements.add(i + 1, Either.left(shift ? description(gem, false) : hint()));
            return;
        }
    }

    // ------------------------------------------------------------------ helpers

    private static List<Found> knownGems(ItemEnchantments enchantments) {
        List<Found> out = new ArrayList<>();
        if (enchantments == null || enchantments.isEmpty()) {
            return out;
        }
        for (Object2IntMap.Entry<Holder<Enchantment>> entry : enchantments.entrySet()) {
            Gem gem = Gems.find(entry.getKey());
            if (gem != null) {
                out.add(new Found(gem, entry.getIntValue(), entry.getKey()));
            }
        }
        return out;
    }

    private static List<Found> longestNameFirst(List<Found> list) {
        List<Found> sorted = new ArrayList<>(list);
        sorted.sort(Comparator.comparingInt((Found f) -> f.gem().name().length()).reversed());
        return sorted;
    }

    /**
     * Finds the tooltip line that shows this enchantment (never a hard-coded position, other mods add lines).
     * First an exact match with the real displayed name, then "gem name" / "gem name + level" (longest name first).
     */
    private static int indexOfLine(List<Component> tip, Found found, Set<Integer> used) {
        String expected = Enchantment.getFullname(found.holder(), found.level()).getString();
        for (int i = 1; i < tip.size(); i++) {
            if (!used.contains(i) && tip.get(i).getString().equals(expected)) {
                return i;
            }
        }
        String name = found.gem().name();
        for (int i = 1; i < tip.size(); i++) {
            if (used.contains(i)) {
                continue;
            }
            String s = tip.get(i).getString();
            if (s.equals(name) || s.startsWith(name + " ")) {
                return i;
            }
        }
        return -1;
    }

    private static Style color(Gem gem) {
        return Style.EMPTY.withColor(TextColor.fromRgb(gem.color()));
    }

    private static Component levelComponent(int level) {
        return level >= 1 && level <= 10
                ? Component.translatable("enchantment.level." + level)
                : Component.literal(Integer.toString(level));
    }

    private static Component nameLine(Found f) {
        MutableComponent line = Component.literal(f.gem().name());
        if (f.level() != 1 || f.holder().value().getMaxLevel() != 1) {
            line.append(" ").append(levelComponent(f.level()));
        }
        return line.withStyle(color(f.gem()));
    }

    private static Component description(Gem gem, boolean indent) {
        return Component.literal((indent ? "  " : "") + gem.description()).withStyle(ChatFormatting.GRAY);
    }

    private static Component hint() {
        return Component.literal(HINT_TEXT).withStyle(ChatFormatting.DARK_GRAY);
    }
}
