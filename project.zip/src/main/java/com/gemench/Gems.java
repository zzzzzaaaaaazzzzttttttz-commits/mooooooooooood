package com.gemench;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import net.minecraft.core.Holder;
import net.minecraft.world.item.enchantment.Enchantment;

/** Every enchantment that has a gem. The array index decides the book sprite (index + 1 is the model property value). */
public final class Gems {
    public static final List<Gem> ALL = List.of(
        new Gem("minecraft:protection", "Diamond", 0xBFE8F5, "Reduces most types of damage.", "diamond", 0),
        new Gem("minecraft:fire_protection", "Ruby", 0xD4142F, "Reduces fire damage and burn time.", "ruby", 1),
        new Gem("minecraft:blast_protection", "Carnelian", 0xC2491F, "Reduces explosion damage and knockback.", "carnelian", 2),
        new Gem("minecraft:projectile_protection", "Hematite", 0x6A6E78, "Reduces damage from arrows and other projectiles.", "hematite", 3),
        new Gem("minecraft:thorns", "Tourmaline", 0x1F8A5B, "Damages attackers when they hit you.", "tourmaline", 4),
        new Gem("minecraft:unbreaking", "Sapphire", 0x3D61C3, "Gives items a chance not to lose durability.", "sapphire", 5),
        new Gem("minecraft:mending", "Emerald", 0x1FAE5E, "Repairs the item using XP orbs.", "emerald", 6),
        new Gem("minecraft:binding_curse", "Amber", 0xE0901A, "Armor cannot be removed once worn.", "amber", 7),
        new Gem("minecraft:vanishing_curse", "Moonstone", 0xC9D3EA, "Item disappears when you die.", "moonstone", 8),
        new Gem("minecraft:respiration", "Aquamarine", 0x6FD3D6, "Extends breathing time underwater.", "aquamarine", 9),
        new Gem("minecraft:aqua_affinity", "Blue Chalcedony", 0x8FB8E0, "Removes the underwater mining speed penalty.", "blue_chalcedony", 10),
        new Gem("minecraft:swift_sneak", "Smoky Quartz", 0x6B5A4C, "Lets you move faster while sneaking.", "smoky_quartz", 11),
        new Gem("minecraft:feather_falling", "Opal", 0xD8E6EF, "Reduces fall damage.", "opal", 12),
        new Gem("minecraft:depth_strider", "Turquoise", 0x2BC0B4, "Increases movement speed underwater.", "turquoise", 13),
        new Gem("minecraft:frost_walker", "Selenite", 0xEEF4F7, "Freezes water under your feet into ice.", "selenite", 14),
        new Gem("minecraft:soul_speed", "Amethyst", 0x8E4FD0, "Increases speed on soul sand and soul soil.", "amethyst", 15),
        new Gem("minecraft:sharpness", "Moissanite", 0xE4F0FF, "Increases melee damage to all mobs.", "moissanite", 16),
        new Gem("minecraft:smite", "Peridot", 0x9BC92B, "Increases damage to undead mobs.", "peridot", 17),
        new Gem("minecraft:bane_of_arthropods", "Tiger's Eye", 0xB0731F, "Increases damage to spiders and silverfish, and slows them.", "tigers_eye", 18),
        new Gem("minecraft:knockback", "Lapis Lazuli", 0x475EAA, "Pushes enemies further back when hit.", "lapis_lazuli", 19),
        new Gem("minecraft:fire_aspect", "Fire Opal", 0xFF6A1A, "Sets the target on fire.", "fire_opal", 20),
        new Gem("minecraft:looting", "Golden Beryl", 0xE8C33A, "Increases mob loot drops.", "golden_beryl", 21),
        new Gem("minecraft:sweeping_edge", "Kyanite", 0x3B78D6, "Increases sweep attack damage (swords).", "kyanite", 22),
        new Gem("minecraft:efficiency", "Topaz", 0xF0A53A, "Increases mining speed.", "topaz", 23),
        new Gem("minecraft:silk_touch", "Rose Quartz", 0xF3B6C8, "Mines blocks in their original form (glass, ice, ores).", "rose_quartz", 24),
        new Gem("minecraft:fortune", "Citrine", 0xF2B81C, "Increases drops from ores and some blocks.", "citrine", 25),
        new Gem("minecraft:power", "Red Spinel", 0xC63150, "Increases arrow damage.", "red_spinel", 26),
        new Gem("minecraft:punch", "Garnet", 0xA34051, "Increases arrow knockback.", "garnet", 27),
        new Gem("minecraft:flame", "Sunstone", 0xF08A2C, "Arrows set targets on fire.", "sunstone", 28),
        new Gem("minecraft:infinity", "Alexandrite", 0x2E8F86, "Shoot without consuming arrows.", "alexandrite", 29),
        new Gem("minecraft:multishot", "Labradorite", 0x3F7FA0, "Fires three arrows at once.", "labradorite", 30),
        new Gem("minecraft:piercing", "Tanzanite", 0x4A4FC4, "Arrows pass through multiple entities.", "tanzanite", 31),
        new Gem("minecraft:quick_charge", "Zircon", 0x5EC0E8, "Reloads the crossbow faster.", "zircon", 32),
        new Gem("minecraft:loyalty", "Pearl", 0xF1EBE3, "Trident returns to you after being thrown.", "pearl", 33),
        new Gem("minecraft:impaling", "Onyx", 0x66656B, "Extra damage to aquatic mobs.", "onyx", 34),
        new Gem("minecraft:riptide", "Larimar", 0x4FB6D9, "Launches you forward in water or rain.", "larimar", 35),
        new Gem("minecraft:channeling", "Charoite", 0x7B3FA8, "Summons lightning on hit during a thunderstorm.", "charoite", 36),
        new Gem("minecraft:density", "Jasper", 0xA8472D, "Increases smash attack damage per block fallen.", "jasper", 37),
        new Gem("minecraft:breach", "Bloodstone", 0x4E735D, "Reduces the effectiveness of the target's armor.", "bloodstone", 38),
        new Gem("minecraft:wind_burst", "Celestite", 0xA9CDF0, "Launches you upward after a smash attack.", "celestite", 39),
        new Gem("minecraft:luck_of_the_sea", "Jade", 0x4FAE7A, "Increases chance of treasure catches.", "jade", 40),
        new Gem("minecraft:lure", "Rhodochrosite", 0xE0728F, "Makes fish bite faster.", "rhodochrosite", 41),
        new Gem("minecraft:lunge", "Rhodolite", 0xB0306A, "Lunges you forward when you jab with a spear (uses hunger).", "rhodolite", 42),
        new Gem("apothic_enchanting:berserkers_fury", "Cinnabar", 0xAA0000, "Gain Resistance, Speed and Strength after taking damage.", "cinnabar", 43),
        new Gem("apothic_enchanting:boon_of_the_earth", "Malachite", 0x00AA00, "Chance to get ores when mining plain stone.", "malachite", 44),
        new Gem("apothic_enchanting:chainsaw", "Moss Agate", 0x00AA00, "Breaking one log fells the whole tree.", "moss_agate", 45),
        new Gem("apothic_enchanting:chromatic", "Fluorite", 0x6FD0B0, "Shearing a sheep gives a random wool color.", "fluorite", 46),
        new Gem("apothic_enchanting:crescendo_of_bolts", "Kunzite", 0x00AA00, "Fires extra free bolts per level.", "kunzite", 47),
        new Gem("apothic_enchanting:endless_quiver", "Rutilated Quartz", 0x00AA00, "Arrows are never used up.", "rutilated_quartz", 48),
        new Gem("apothic_enchanting:growth_serum", "Chrysoprase", 0x00AA00, "Sheared sheep may regrow wool instantly (50%).", "chrysoprase", 49),
        new Gem("apothic_enchanting:icy_thorns", "Apatite", 0x22B8D4, "Slows attackers; lasts longer with level.", "apatite", 50),
        new Gem("apothic_enchanting:knowledge_of_the_ages", "Ammolite", 0x00AA00, "Mob drops turn into XP orbs.", "ammolite", 51),
        new Gem("apothic_enchanting:life_mending", "Rhodonite", 0xAA0000, "Healing you receive repairs the item instead of XP.", "rhodonite", 52),
        new Gem("apothic_enchanting:miners_fervor", "Pyrite", 0xAA00AA, "Break blocks fast, but never instantly.", "pyrite", 53),
        new Gem("apothic_enchanting:natures_blessing", "Aventurine", 0x4FA86A, "The hoe works like bone meal.", "aventurine", 54),
        new Gem("apothic_enchanting:rebounding", "Obsidian", 0x6A6277, "Knocks back melee attackers.", "obsidian", 55),
        new Gem("apothic_enchanting:reflective_defenses", "Cat's Eye", 0xB8C24A, "Reflects 15% of blocked damage back (more at higher levels).", "cats_eye", 56),
        new Gem("apothic_enchanting:scavenger", "Moldavite", 0x00AA00, "2.5% chance per level to roll mob loot twice.", "moldavite", 57),
        new Gem("apothic_enchanting:shield_bash", "Sardonyx", 0xA8412A, "Melee attacks with a shield deal extra damage.", "sardonyx", 58),
        new Gem("apothic_enchanting:stable_footing", "Iolite", 0x5A5FB5, "No mining speed penalty while flying.", "iolite", 59),
        new Gem("apothic_enchanting:tempting", "Morganite", 0xF0B9A8, "Animals follow you while you hold the hoe.", "morganite", 60),
        new Gem("apothic_enchanting:worker_exploitation", "Bixbite", 0xAA00AA, "Hurts sheep but doubles wool.", "bixbite", 61),
        new Gem("alexsmobs:board_return", "Sodalite", 0x2F58A8, "Straddleboard returns instantly to the rider's inventory when broken.", "sodalite", 62),
        new Gem("alexsmobs:lavawax", "Spessartine", 0xE07A1F, "Gives the rider of the Straddleboard Fire Resistance.", "spessartine", 63),
        new Gem("alexsmobs:serpentfriend", "Serpentine", 0x5F8F5A, "Makes Bone Serpents neutral towards the rider of the Straddleboard.", "serpentine", 64),
        new Gem("alexsmobs:straddle_jump", "Azurite", 0x4169AE, "Increases the height of Straddleboard jumps.", "azurite", 65),
        new Gem("betterarcheology:penetrating_strike", "Painite", 0xA0422F, "Partly bypasses protection enchantments.", "painite", 66),
        new Gem("betterarcheology:soaring_winds", "Apophyllite", 0xD8F0E0, "Boosts elytra takeoff.", "apophyllite", 67),
        new Gem("betterarcheology:tunneling", "Cassiterite", 0x735D4F, "Mines an extra block below.", "cassiterite", 68)
    );

    private static final Map<String, Gem> BY_ENCHANT = new HashMap<>();
    private static final List<Gem> BY_NAME_LENGTH = new ArrayList<>();

    static {
        for (Gem g : ALL) {
            BY_ENCHANT.put(g.enchantId(), g);
        }
        BY_NAME_LENGTH.addAll(ALL);
        BY_NAME_LENGTH.sort(Comparator.comparingInt((Gem g) -> g.name().length()).reversed());
    }

    private Gems() {}

    public static Gem byEnchantId(String id) {
        return BY_ENCHANT.get(id);
    }

    /** Gem of an enchantment holder, or null when the enchantment has no gem (other mods keep working normally). */
    public static Gem find(Holder<Enchantment> holder) {
        return holder.unwrapKey().map(key -> BY_ENCHANT.get(key.identifier().toString())).orElse(null);
    }

    /** Matches a displayed name such as "Fire Opal II": the longest gem name wins. */
    public static Gem matchDisplayName(String shown) {
        for (Gem g : BY_NAME_LENGTH) {
            String n = g.name();
            if (shown.equals(n) || shown.startsWith(n + " ")) {
                return g;
            }
        }
        return null;
    }
}
