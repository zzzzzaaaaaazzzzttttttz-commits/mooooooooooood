package com.gemench;

/**
 * One gem.
 *
 * @param enchantId   enchantment id, for example "minecraft:sharpness"
 * @param name        gem name shown instead of the enchantment name
 * @param color       text color (already lightened when the gem color is too dark)
 * @param description what the enchantment does (shown while Shift is held)
 * @param gemId       sprite id, for example "tigers_eye"
 * @param index       position in {@link Gems#ALL}
 */
public record Gem(String enchantId, String name, int color, String description, String gemId, int index) {}
